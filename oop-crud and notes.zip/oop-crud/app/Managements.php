<?php  


	/**
	 * All funcitons 
	 */
	class Managements
	{
		
		


	}











?>