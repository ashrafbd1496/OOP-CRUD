<?php  
	
	include_once "DB.php";
	include_once "Managements.php";
	include_once "User.php";


?>